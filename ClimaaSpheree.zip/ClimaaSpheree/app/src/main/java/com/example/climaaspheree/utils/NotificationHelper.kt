package com.example.climaaspheree.utils

object NotificationHelper {
    var isNotificationsEnabled: Boolean = true
}

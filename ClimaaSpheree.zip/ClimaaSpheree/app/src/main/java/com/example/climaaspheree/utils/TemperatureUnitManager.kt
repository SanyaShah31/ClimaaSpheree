package com.example.climaaspheree.utils

object TemperatureUnitManager {
    var isDualUnitEnabled: Boolean = false
}
